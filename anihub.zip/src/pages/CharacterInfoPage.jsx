import React from "react";

const CharacterInfoPage = () => {
  return (
    <div className="h-screen flex justify-center items-center">
      <h1>not implemented</h1>
    </div>
  );
};

export default CharacterInfoPage;
